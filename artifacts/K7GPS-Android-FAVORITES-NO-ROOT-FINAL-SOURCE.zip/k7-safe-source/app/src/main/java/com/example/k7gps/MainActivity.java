package com.example.k7gps;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.content.SharedPreferences;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQ_CODE = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnStartService = findViewById(R.id.btn_start_service);
        btnStartService.setOnClickListener(v -> checkPermissionsAndStart());

        EditText name = findViewById(R.id.favorite_name);
        EditText lat = findViewById(R.id.favorite_lat);
        EditText lng = findViewById(R.id.favorite_lng);
        ListView list = findViewById(R.id.favorites_list);
        SharedPreferences prefs = getSharedPreferences("wolfox_favorites", MODE_PRIVATE);
        ArrayList<String> favorites = new ArrayList<>();
        String stored = prefs.getString("items", "");
        if (!stored.isEmpty()) favorites.addAll(Arrays.asList(stored.split("\\n")));
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, favorites);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            String[] parts = favorites.get(position).split("\\|", 3);
            if (parts.length == 3) {
                name.setText(parts[0]); lat.setText(parts[1]); lng.setText(parts[2]);
            }
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            favorites.remove(position);
            prefs.edit().putString("items", String.join("\\n", favorites)).apply();
            adapter.notifyDataSetChanged();
            return true;
        });
        findViewById(R.id.btn_save_favorite).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String la = lat.getText().toString().trim();
            String lo = lng.getText().toString().trim();
            try {
                double dLat = Double.parseDouble(la), dLng = Double.parseDouble(lo);
                if (n.isEmpty() || dLat < -90 || dLat > 90 || dLng < -180 || dLng > 180)
                    throw new IllegalArgumentException();
                String item = String.format(Locale.US, "%s|%.7f|%.7f", n, dLat, dLng);
                favorites.add(item);
                prefs.edit().putString("items", String.join("\\n", favorites)).apply();
                adapter.notifyDataSetChanged();
                Toast.makeText(this, "تم حفظ الموقع", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "أدخل اسمًا وإحداثيات صحيحة", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkPermissionsAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_PERMISSION_REQ_CODE);
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل صلاحية النافذة العائمة من إعدادات النظام لتشغيلها", Toast.LENGTH_LONG).show();
            return;
        }

        // تشغيل الخدمة
        startFloatingService();
    }

    private void startFloatingService() {
        Intent intent = new Intent(this, FloatingGpsService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        finish();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQ_CODE
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            checkPermissionsAndStart();
        } else if (requestCode == LOCATION_PERMISSION_REQ_CODE) {
            Toast.makeText(this, "تم رفض صلاحية الموقع؛ لم يتم تشغيل الخدمة", Toast.LENGTH_SHORT).show();
        }
    }

}
