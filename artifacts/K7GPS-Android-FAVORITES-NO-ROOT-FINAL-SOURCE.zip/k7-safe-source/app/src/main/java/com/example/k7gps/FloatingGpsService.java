package com.example.k7gps;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;

public class FloatingGpsService extends Service {

    private WindowManager windowManager;
    private View floatingView;
    private MockLocationManager mockManager;
    private Handler handler;
    private Runnable pushRunnable;

    private double currentLat = 24.713600;
    private double currentLng = 46.675301;
    private boolean isMocking = false;
    private boolean randomWalkEnabled = true;
    private double jitterRadius = 20.0; // 20 متر افتراضياً مثل الصورة

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundNotification();

        mockManager = new MockLocationManager(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        handler = new Handler(Looper.getMainLooper());

        initOverlayView();
    }

    private void initOverlayView() {
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_gps, null);

        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.CENTER;
        params.x = 0;
        params.y = 0;

        windowManager.addView(floatingView, params);

        // ربط العناصر
        TextView tvStatus = floatingView.findViewById(R.id.tv_status);
        EditText etCoords = floatingView.findViewById(R.id.et_coords);
        Button btnToggle = floatingView.findViewById(R.id.btn_toggle);
        Button btnRandom = floatingView.findViewById(R.id.btn_random);
        Button btnClose = floatingView.findViewById(R.id.btn_close);
        Button btnHide = floatingView.findViewById(R.id.btn_hide);
        View rootCard = floatingView.findViewById(R.id.card_root);

        etCoords.setText(String.format("%.6f, %.6f", currentLat, currentLng));

        btnToggle.setOnClickListener(v -> {
            if (!isMocking) {
                // قراءة الإحداثيات المدخلة
                parseCoordinates(etCoords.getText().toString());
                boolean started = mockManager.startMocking();
                if (started) {
                    isMocking = true;
                    btnToggle.setText("إيقاف ■");
                    tvStatus.setText("التزييف: مفعل");
                    startLocationLoop();
                } else {
                    Toast.makeText(this, "تأكد من اختيار التطبيق في خيارات المطور (Mock App)", Toast.LENGTH_LONG).show();
                }
            } else {
                stopLocationLoop();
                mockManager.stopMocking();
                isMocking = false;
                btnToggle.setText("تشغيل ▶");
                tvStatus.setText("التزييف: متوقف");
            }
        });

        btnRandom.setOnClickListener(v -> {
            randomWalkEnabled = !randomWalkEnabled;
            btnRandom.setText(randomWalkEnabled ? "حركة عشوائية ( 20م )" : "حركة عشوائية ( معطل )");
        });

        btnHide.setOnClickListener(v -> {
            // إخفاء المحتوى وإبقاء زر صغير أو تصغير
            Toast.makeText(this, "تم تصغير الأداة", Toast.LENGTH_SHORT).show();
        });

        btnClose.setOnClickListener(v -> stopSelf());

        // سحب النافذة وتحريكها
        rootCard.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                        return true;
                }
                return false;
            }
        });
    }

    private void parseCoordinates(String text) {
        try {
            String[] parts = text.split(",");
            if (parts.length == 2) {
                currentLat = Double.parseDouble(parts[0].trim());
                currentLng = Double.parseDouble(parts[1].trim());
            }
        } catch (Exception ignored) {}
    }

    private void startLocationLoop() {
        pushRunnable = new Runnable() {
            @Override
            public void run() {
                mockManager.pushLocation(currentLat, currentLng, randomWalkEnabled ? jitterRadius : 0.0);
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(pushRunnable);
    }

    private void stopLocationLoop() {
        if (handler != null && pushRunnable != null) {
            handler.removeCallbacks(pushRunnable);
        }
    }

    private void startForegroundNotification() {
        String channelId = "k7gps_channel";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelId, "K7GPS Service", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }

        Notification notification = new NotificationCompat.Builder(this, channelId)
                .setContentTitle("K7GPS Overlay")
                .setContentText("أداة محاكاة الموقع نشطة في الخلفية")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build();

        startForeground(1, notification);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopLocationLoop();
        if (mockManager != null) mockManager.stopMocking();
        if (floatingView != null && windowManager != null) windowManager.removeView(floatingView);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
