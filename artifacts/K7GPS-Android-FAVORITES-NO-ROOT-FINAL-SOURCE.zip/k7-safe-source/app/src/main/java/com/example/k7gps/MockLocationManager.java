package com.example.k7gps;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.location.provider.ProviderProperties;
import android.os.Build;
import android.os.SystemClock;
import java.util.Random;

public class MockLocationManager {

    private final LocationManager locationManager;
    private final String providerName = LocationManager.GPS_PROVIDER;
    private final Random random = new Random();

    public MockLocationManager(Context context) {
        this.locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
    }

    public boolean startMocking() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                locationManager.addTestProvider(
                        providerName,
                        false, false, false, false, true, true, true,
                        ProviderProperties.POWER_USAGE_LOW,
                        ProviderProperties.ACCURACY_FINE
                );
            } else {
                locationManager.addTestProvider(
                        providerName,
                        false, false, false, false, true, true, true,
                        1, 1
                );
            }
            locationManager.setTestProviderEnabled(providerName, true);
            return true;
        } catch (SecurityException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void pushLocation(double lat, double lng, double jitterRadiusMeters) {
        if (jitterRadiusMeters > 0) {
            // إضافة حركة عشوائية دائرية
            double radiusInDegrees = jitterRadiusMeters / 111000.0;
            double u = random.nextDouble();
            double v = random.nextDouble();
            double w = radiusInDegrees * Math.sqrt(u);
            double t = 2 * Math.PI * v;
            lat += w * Math.cos(t);
            lng += (w * Math.sin(t)) / Math.cos(Math.toRadians(lat));
        }

        Location mockLoc = new Location(providerName);
        mockLoc.setLatitude(lat);
        mockLoc.setLongitude(lng);
        mockLoc.setAltitude(15.0);
        mockLoc.setTime(System.currentTimeMillis());
        mockLoc.setAccuracy(3.0f);
        mockLoc.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());

        try {
            locationManager.setTestProviderLocation(providerName, mockLoc);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stopMocking() {
        try {
            locationManager.removeTestProvider(providerName);
        } catch (Exception ignored) {}
    }
}
